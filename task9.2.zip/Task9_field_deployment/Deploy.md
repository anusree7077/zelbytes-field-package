# Deployment Guide

## Flash Steps
1. Connect ESP32 to PC using USB cable.
2. Open Arduino IDE.
3. Select correct COM port.
4. Upload firmware.
5. Open Serial Monitor and verify output.

## Wi-Fi Provisioning
1. Open config.json
2. Enter Wi-Fi SSID and password
3. Save file
4. Flash device again

## Rollback Procedure
1. If firmware fails, reconnect ESP32
2. Upload previous stable firmware
3. Verify telemetry is restored