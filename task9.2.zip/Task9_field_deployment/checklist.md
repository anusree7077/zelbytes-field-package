# Deployment Checklist

- [x] Firmware bundle ready
- [x] Config file prepared
- [x] Flash steps documented
- [x] Wi-Fi provisioning documented
- [x] Rollback procedure documented